package getRequestTests;

import commonUtils.Base;
import commonUtils.ReadProperties;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.ArrayList;


public class getTitles extends Base {

    ReadProperties readProperties = new ReadProperties();
    String path;

    @BeforeClass
    public void setReadProperties(){
        //Setting all the property values
        path = readProperties.getPropertyValue("path");
    }

    @Test
    public void testResponse()
    {
        //Read the path and replace the stop which we want to run api
        Response response = RestAssured.given()
                .get(path);

        JsonPath jsonPath = new JsonPath(response.getBody().asString());
        ArrayList titles = jsonPath.get("items.carouselItems.title");
        System.out.println(titles);
        //Can do more assertions like this
        Assert.assertTrue(titles.toString().contains("Hot In Cleveland"));
        System.out.println("Assertion success");

    }


}